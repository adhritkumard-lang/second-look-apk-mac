#!/bin/bash
# Builds "Second Look.app" and a drag-to-install SecondLook.dmg. Run on a Mac.
set -euo pipefail
cd "$(dirname "$0")"

APP="Second Look"
OUT="build"
FRAMEWORKS="-framework Cocoa -framework WebKit -framework Vision"

if ! command -v swiftc >/dev/null 2>&1; then
  echo "This needs Apple's command line tools. Install them with:  xcode-select --install"
  echo "Then run this script again."
  exit 1
fi

rm -rf "$OUT"
mkdir -p "$OUT/$APP.app/Contents/MacOS" "$OUT/$APP.app/Contents/Resources" "$OUT/dmg"

echo "1/5 Compiling the app..."
if swiftc -O -target arm64-apple-macos12.0 $FRAMEWORKS SecondLook.swift -o "$OUT/SecondLook-arm64" 2>/dev/null \
   && swiftc -O -target x86_64-apple-macos12.0 $FRAMEWORKS SecondLook.swift -o "$OUT/SecondLook-x86_64" 2>/dev/null; then
  lipo -create "$OUT/SecondLook-arm64" "$OUT/SecondLook-x86_64" -output "$OUT/$APP.app/Contents/MacOS/SecondLook"
  echo "    built for Apple silicon and Intel"
else
  echo "    universal build unavailable, building for this Mac only"
  swiftc -O $FRAMEWORKS SecondLook.swift -o "$OUT/$APP.app/Contents/MacOS/SecondLook"
fi

echo "2/5 Adding the website and icon..."
cp Info.plist "$OUT/$APP.app/Contents/Info.plist"
cp -R web "$OUT/$APP.app/Contents/Resources/web"
iconutil -c icns AppIcon.iconset -o "$OUT/$APP.app/Contents/Resources/AppIcon.icns"

echo "3/5 Signing (ad hoc, so it runs on this Mac)..."
codesign --force --deep --sign - "$OUT/$APP.app"

echo "4/5 Preparing the disk image..."
cp -R "$OUT/$APP.app" "$OUT/dmg/"
ln -s /Applications "$OUT/dmg/Applications"

echo "5/5 Creating SecondLook.dmg..."
rm -f SecondLook.dmg
hdiutil create -volname "Second Look" -srcfolder "$OUT/dmg" -ov -format UDZO SecondLook.dmg >/dev/null

echo
echo "Done. Your installer is here:  $(pwd)/SecondLook.dmg"
open -R SecondLook.dmg 2>/dev/null || true
