SECOND LOOK FOR MAC
===================

This folder builds a Mac app ("Second Look.app") and a drag-to-install disk
image (SecondLook.dmg). A .dmg can only be created on a Mac, so you run one
command and it makes the file for you.

WHAT YOU NEED
- A Mac running macOS 12 (Monterey) or newer
- Apple's free command line tools. If you don't have them, the build tells you
  to run this in Terminal:   xcode-select --install
  (a one-time download of roughly 1 GB)

HOW TO BUILD
1. Unzip this folder anywhere.
2. Double-click "Build Second Look.command".
   If macOS says it can't be opened: right-click it, choose Open, then Open.
   Or in Terminal:   cd path/to/SecondLook-Mac && ./build.sh
3. After a minute or two, SecondLook.dmg appears in this folder.

HOW TO INSTALL
1. Double-click SecondLook.dmg.
2. Drag "Second Look" onto the Applications folder.
3. Open it from Applications or Launchpad.

HOW THE APP WORKS
- Drop a screenshot onto the window, paste one with Command+V, or choose a
  picture. The text is read on your Mac with Apple's built-in text recognition,
  so nothing is uploaded and no account is needed.
- Or switch to "Paste text" and paste the message.
- The scam check itself runs entirely inside the app.

WHAT THE MAC APP LEAVES OUT
- The Claude-powered extras (full review, typed follow-up questions, and
  reading logos in pictures) only work in the claude.ai version of the site.
- Feedback can't be sent automatically. The form gives people text to copy.
- It looks best online (the fonts download), but it works offline too.

SHARING THE DMG WITH OTHER PEOPLE
The app is signed only for your own Mac. If you send the .dmg to someone else,
macOS will warn that it is from an unidentified developer. They can open it with
right-click > Open, or through System Settings > Privacy & Security > Open Anyway.
To remove that warning you need an Apple Developer account ($99/year) to sign
and notarize the app. I can walk you through that.

IF THE BUILD FAILS
Copy the error text from Terminal and send it to me. The app has not been
compiled on a Mac by me, so a first-run fix is possible.

FILES
- web/index.html       the website (also works if you double-click it in a browser)
- SecondLook.swift     the app shell and the screenshot text reader
- Info.plist           app settings
- AppIcon.iconset/     the icon
- build.sh             builds the app and the .dmg
